﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FractionConsoleApp
{
    public class FractionNumber
    {
        private int numerator; //licznik

        public int Numerator
        {
            get { return numerator; }   
            set { numerator = value; }
        }

        private int denominator; //mianownik

        public int Denominator
        {
            get { return denominator; }
            set
            {
                if (value !=0)
                
                    denominator = value;

                    else
                        throw new ArgumentException("Nie mozna wstawic zera");
                
            }
        }

        public FractionNumber()
        {
            Numerator = 0;
            Denominator = 1;
        }

        public FractionNumber(int n, int d)
        {
            Numerator = n;
            Denominator = d;
        }

        public override string ToString()
        {
            return numerator + "\\" + denominator;
        }

        public void Mul(FractionNumber firstFraction, FractionNumber secondFraction)
        {
            Numerator = firstFraction.Numerator + secondFraction.Numerator; 
            Denominator = firstFraction.Denominator + secondFraction.Denominator;  
        }

        public FractionNumber Mul(FractionNumber secondFraction)
        {
            throw new NotImplementedException();
        }
    }
}