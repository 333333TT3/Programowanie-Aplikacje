﻿using Geometria;

Point p = new Point();
p.SetX(5);
p.Y = 8;
p.Display();
Console.WriteLine( "Odleglosc od punktu (0,0) wynosi" + p.DistanceFromCenter);

Point p2 = new Point();
p.SetX(68);
p.Y = 78;
p.Display(); 