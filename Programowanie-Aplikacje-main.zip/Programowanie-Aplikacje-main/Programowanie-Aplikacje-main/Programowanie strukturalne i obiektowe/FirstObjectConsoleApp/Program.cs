﻿using System;

namespace FirstObjectConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            int x;
            x = 15;

            Person p;
            p = new Person();
            p.ShowInfo();
        }
    }
}
