﻿using Geometria;

Point p = new Point();
p.x = 4;
p.y = 8;
p.Display();
