
void PrzykladowaFunkcja(int x)
{
	int y;
}

int main()
{
	int a;
	int y;
	{
		int g;
	}
	int c;
	PrzykladowaFunkcja(5);

	int h;
	PrzykladowaFunkcja(5);
}

